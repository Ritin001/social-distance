import cv2
import numpy as np
import imutils
import torch
from scipy.spatial.distance import euclidean

# -----------------------------------------------------------------------------
# File Paths and Configuration
# -----------------------------------------------------------------------------

# We'll use the YOLOv5 model directly from its repository
MODEL_PATH = 'yolov5'
WEIGHTS_PATH = 'yolov5s.pt' # This is a smaller, faster model

# Set the minimum social distance threshold in pixels.
# This value may need to be adjusted based on your camera and viewing angle.
MIN_DISTANCE = 500

# -----------------------------------------------------------------------------
# Main Detector Function
# -----------------------------------------------------------------------------

def detect_social_distancing():
    """
    This function handles the main video processing loop using YOLOv5.
    It performs person detection, distance calculation, and displays alerts.
    """
    # Load the YOLOv5 model from the local repository
    print("[INFO] Loading YOLOv5 model...")
    try:
        model = torch.hub.load(MODEL_PATH, 'custom', path=WEIGHTS_PATH, source='local')
        # Filter for only the 'person' class, which is class 0 in COCO dataset
        model.classes = [0]
    except Exception as e:
        print(f"[ERROR] Failed to load YOLOv5 model: {e}")
        print("Please make sure you have the 'yolov5' folder in your project directory and have run 'pip install -r requirements.txt'")
        return

    # Initialize the video stream
    print("[INFO] Starting video stream...")
    # Use 0 for webcam, or specify a video file path
    vs = cv2.VideoCapture(0)

    # Loop over the frames from the video stream
    while True:
        # Read the next frame from the video stream
        ret, frame = vs.read()

        # If the frame was not grabbed, then we have reached the end of the stream
        if not ret:
            break

        # Resize the frame for faster processing and get its dimensions
        frame = imutils.resize(frame, width=800)
        (H, W) = frame.shape[:2]

        # Perform inference on the frame
        results = model(frame)
        
        # Get the detected bounding boxes for people
        person_boxes = []
        # The results.xyxy[0] contains the bounding boxes, confidence, and class ID
        for *box, conf, cls in results.xyxy[0]:
            x1, y1, x2, y2 = [int(i) for i in box]
            person_boxes.append((x1, y1, x2 - x1, y2 - y1))

        # ---------------------------------------------------------------------
        # Step 1: Distance Calculation
        # ---------------------------------------------------------------------
        violations = set()
        if len(person_boxes) > 1:
            for i in range(len(person_boxes)):
                for j in range(i + 1, len(person_boxes)):
                    box_a = person_boxes[i]
                    box_b = person_boxes[j]

                    # Get the bottom-center point of each bounding box
                    center_a = (box_a[0] + box_a[2] // 2, box_a[1] + box_a[3])
                    center_b = (box_b[0] + box_b[2] // 2, box_b[1] + box_b[3])
                    
                    # Calculate the Euclidean distance
                    distance = euclidean(center_a, center_b)
                    
                    # --- DEBUGGING LINE ---
                    print(f"Calculated distance: {distance:.2f} pixels")
                    # ----------------------

                    # Check if the distance is less than the minimum threshold
                    if distance < MIN_DISTANCE:
                        violations.add(i)
                        violations.add(j)
                        
                        # Draw a red line between the two people to show the violation
                        cv2.line(frame, center_a, center_b, (0, 0, 255), 2)
        
        # ---------------------------------------------------------------------
        # Step 2: Visualization
        # ---------------------------------------------------------------------
        for i, box in enumerate(person_boxes):
            (x, y, w, h) = box
            
            # Set the color based on whether a violation was detected
            color = (0, 0, 255) if i in violations else (0, 255, 0)
            
            # Draw the bounding box
            cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
            
        # Display the number of social distancing violations
        text = "Social Distancing Violations: {}".format(len(violations))
        cv2.putText(frame, text, (10, H - 25), cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 0, 255), 3)


        # Display the processed frame
        cv2.imshow("Social Distance Detector", frame)
        
        # Break the loop if the 'q' key is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Clean up and release resources
    vs.release()
    cv2.destroyAllWindows()

# -----------------------------------------------------------------------------
# Main execution block
# -----------------------------------------------------------------------------

if __name__ == "__main__":
    detect_social_distancing()
