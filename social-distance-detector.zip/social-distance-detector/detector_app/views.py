from django.shortcuts import render
from django.http import StreamingHttpResponse
from .detector import detect_social_distancing

def index(request):
    return render(request, 'detector_app/index.html')

def video_feed(request):
    return StreamingHttpResponse(
        detect_social_distancing(),
        content_type='multipart/x-mixed-replace; boundary=frame'
    )